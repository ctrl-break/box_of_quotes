<?php
// No direct access
defined('_JEXEC') or die; ?>
<div class="quotesbox">
    <div class="quote"><?php echo $quote[0]; ?></div>
    <div class="author"><?php echo $quote[1]; ?>
    </div>
</div>
